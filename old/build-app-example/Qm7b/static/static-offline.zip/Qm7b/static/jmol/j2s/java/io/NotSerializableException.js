Clazz.load(["java.io.ObjectStreamException"],"java.io.NotSerializableException",null,function(){
c$=Clazz.declareType(java.io,"NotSerializableException",java.io.ObjectStreamException);
});
