Clazz.declarePackage ("J.api");
c$ = Clazz.declareType (J.api, "JmolAdapterStructureIterator");
